# go-chess
## Multi-Player Chess written entirely in golang and static html/css           
     
~~IIII~~ II
     
I enjoy playing chess with my friends from school, but the schol blocked chess.com, the only way we knew to play chess against eachother. So I did the only logical next move.       
Instead of just finding a new site, I used the Gin-Gonic Framework alongside Gorilla Websockets with Golang's integrated templating system to make multi-player chess that I can temporarily host on a Github Codespace and then send the preview link to my friends.        
For every day I work on this I will add another tally mark at the top to convince myself I didn't waste my time when I could have just found another website.
